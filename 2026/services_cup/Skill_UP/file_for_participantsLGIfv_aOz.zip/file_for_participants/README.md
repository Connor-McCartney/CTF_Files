## Challenge Name: Skill UP

## Description

Welcome to the World of Hunters. You have been chosen by the System to become the Monarch of Shadows. Your journey begins now. As you grow stronger, you will unlock new skills and abilities. Manage them wisely, for they are your key to survival.